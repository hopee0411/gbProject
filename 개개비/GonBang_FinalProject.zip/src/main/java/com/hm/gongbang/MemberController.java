package com.hm.gongbang;

import org.springframework.stereotype.Controller;

@Controller
public class MemberController {

}
