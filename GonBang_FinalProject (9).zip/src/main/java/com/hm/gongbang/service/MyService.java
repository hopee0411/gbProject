package com.hm.gongbang.service;

public class MyService {

}
