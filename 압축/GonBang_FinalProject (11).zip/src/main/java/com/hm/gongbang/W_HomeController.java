package com.hm.gongbang;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

@Controller
public class W_HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	
}
