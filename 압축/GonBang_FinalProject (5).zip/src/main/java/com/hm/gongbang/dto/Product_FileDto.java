package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class Product_FileDto {

}
