package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class GongBangDto {
	//공방 소개
	private int g_articlenum; //글번호 - 기본키
	private String g_title; //제목
	private String g_coutents; //내용
	private int wh_gbnum; //공방 번호 -외래키
}
//시노님 : G