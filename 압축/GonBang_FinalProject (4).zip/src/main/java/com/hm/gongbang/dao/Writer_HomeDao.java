package com.hm.gongbang.dao;

import com.hm.gongbang.dto.Writer_HomeDto;

public interface Writer_HomeDao {

	//공방 이름 / 메모
	Writer_HomeDto getgbNM(Integer wh_gbnum);

}
