package com.hm.gongbang.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.hm.gongbang.dao.Writer_HomeDao;
import com.hm.gongbang.dto.Writer_HomeDto;

import lombok.extern.java.Log;

@Service
@Log
public class W_HomeService {

	//작가홈 출력 Dao
	@Autowired
	private Writer_HomeDao whDao;
	
	private ModelAndView mv;
	
	//정보저장 세션
	@Autowired
	private HttpSession session;
	
	public ModelAndView getWHSideInfo(Integer wh_gbnum) {
		log.info("getWHSideInfo()");
		
		mv = new ModelAndView();
		
		//가져올거
		//1. 공방 이름 / 메모
		Writer_HomeDto gbNM = whDao.getgbNM(wh_gbnum); 
		
		//가져온 데이터 mv에 담기
		mv.addObject("gbNM", gbNM);

		//보여질 페이지 지정
		mv.setViewName("w_WriterHome");
		
		return mv;
	}



}
