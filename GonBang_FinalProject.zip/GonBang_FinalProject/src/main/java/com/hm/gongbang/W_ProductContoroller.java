package com.hm.gongbang;

import org.springframework.stereotype.Controller;

import lombok.extern.java.Log;

@Log
@Controller
public class W_ProductContoroller {
	
}
