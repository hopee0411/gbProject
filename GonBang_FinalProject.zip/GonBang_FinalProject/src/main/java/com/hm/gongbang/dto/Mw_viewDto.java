package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class Mw_viewDto {
	
	private String id;
	private String pwd;
	private int mw_code;
	
}//class end
