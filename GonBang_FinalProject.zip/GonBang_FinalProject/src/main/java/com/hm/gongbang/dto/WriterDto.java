package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class WriterDto {
	private String W_ID;
	private String W_PWD;
	private String W_PHONENUM;
	private String W_EMAIL;
	private int W_COMPANYNUM;
	private String W_GENDER;
	private String W_BIRTH;
	private int W_ACCOUNT;
	private int W_NUMFAIL;
	private int W_SELECTION;
	
	
}
