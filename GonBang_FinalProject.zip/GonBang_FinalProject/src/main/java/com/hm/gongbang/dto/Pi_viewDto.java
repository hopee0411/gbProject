package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class Pi_viewDto {
	private String p_productname;
	private int p_productnum;
	private String w_id;
	private int p_price;
	private String m_id;
	private String wh_gbname;
}//class end
