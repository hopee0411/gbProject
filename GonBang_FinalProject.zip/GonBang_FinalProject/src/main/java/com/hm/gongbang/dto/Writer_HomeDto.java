package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class Writer_HomeDto {
	/*
	 * WH_GBNUM NUMBER NOT NULL, -- 공방번호(기본키) WH_GBNAME NVARCHAR2(20) NOT NULL, --
	 * 공방이름 WH_MEMO NVARCHAR2(20), --메모 W_ID NVARCHAR2(20) NOT NULL, -- 작가아이디(외래키)
	 */
}
