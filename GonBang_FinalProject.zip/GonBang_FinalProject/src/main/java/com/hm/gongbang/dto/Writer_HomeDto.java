package com.hm.gongbang.dto;

import lombok.Data;

@Data
public class Writer_HomeDto {

	private int wh_gbnum;
	private String wh_gbname;
	private String wh_memo;
	private String w_id;

	
}
