package com.hm.gongbang.service;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Service
public class W_InfoService {
	
	
	
	public String w_AtPrivateInfoFix(WriterDto writer, RedirectAttributes rttr) {
		String view = null;
		String msg = null;
	}
	
	
	
	
}
