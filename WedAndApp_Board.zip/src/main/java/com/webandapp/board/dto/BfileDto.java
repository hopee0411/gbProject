package com.webandapp.board.dto;

import lombok.Data;

@Data
public class BfileDto {
	private String bf_oriname;
	private String bf_sysname;
}//class end
